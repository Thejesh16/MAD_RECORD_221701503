package com.example.androidfragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment

class MarkDetailsFragment : Fragment() {

    private lateinit var sslcMarkEditText: EditText
    private lateinit var hscMarkEditText: EditText
    private lateinit var ugcgpaEditText: EditText

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_mark_details, container, false)

        // Initialize the EditText fields
        sslcMarkEditText = view.findViewById(R.id.editTextSSLCMark)
        hscMarkEditText = view.findViewById(R.id.editTextHSCMark)
        ugcgpaEditText = view.findViewById(R.id.editTextUGCGPA)

        return view
    }

    // Method to get the entered SSLC mark
    fun getSSLCMark(): String {
        return sslcMarkEditText.text.toString()
    }

    // Method to get the entered HSC mark
    fun getHSCMark(): String {
        return hscMarkEditText.text.toString()
    }

    // Method to get the entered UG CGPA
    fun getUGCGPA(): String {
        return ugcgpaEditText.text.toString()
    }
}