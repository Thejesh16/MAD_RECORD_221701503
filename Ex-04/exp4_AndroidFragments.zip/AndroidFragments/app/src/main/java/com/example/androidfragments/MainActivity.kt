package com.example.androidfragments

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Only load the fragments if this is the first creation of the activity
        if (savedInstanceState == null) {
            // Add the basic details fragment
            supportFragmentManager.beginTransaction()
                .add(R.id.fragment_container_basic_details, BasicDetailsFragment())
                .commit()

            // Add the mark details fragment
            supportFragmentManager.beginTransaction()
                .add(R.id.fragment_container_mark_details, MarkDetailsFragment())
                .commit()
        }
    }
}