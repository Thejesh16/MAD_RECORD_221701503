package com.example.androidfragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment

class BasicDetailsFragment : Fragment() {

    private lateinit var registerNumberEditText: EditText
    private lateinit var nameEditText: EditText
    private lateinit var departmentEditText: EditText

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_basic_details, container, false)

        // Initialize the EditText fields
        registerNumberEditText = view.findViewById(R.id.editTextRegisterNumber)
        nameEditText = view.findViewById(R.id.editTextName)
        departmentEditText = view.findViewById(R.id.editTextDepartment)

        return view
    }

    // Method to get the entered register number
    fun getRegisterNumber(): String {
        return registerNumberEditText.text.toString()
    }

    // Method to get the entered name
    fun getName(): String {
        return nameEditText.text.toString()
    }

    // Method to get the entered department
    fun getDepartment(): String {
        return departmentEditText.text.toString()
    }
}